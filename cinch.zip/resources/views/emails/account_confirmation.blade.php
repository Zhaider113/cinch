<!DOCTYPE html>
<html>
<body>

<p>Hi {{ $name }},</p>
<p>We're Glad to Announce that your account on THOSE WHO TRAVEL has been Confirmed, you can login to Application to use your Account.</p>
<p>Below are your Account Credentials:</p>
<p>Username: {{ $username }}</p>
<p>Password: {{ $password }}</p>
<p>Thanks,</p>
<p>THOSE WHO TRAVEL</p>
</body>
</html>