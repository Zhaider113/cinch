<!DOCTYPE html>
<html>
<body>

<p>Hi,</p>
<p>{{ $code }} is your Password Recovery Code</p>
<p>Thanks,</p>
<p>Cash Wallet</p>
</body>
</html>