
<?php $__env->startSection('content'); ?>

<div class="mt-3">
    <div class="row">
        <div class="col-md-9 ">
            <h4>Categgory List</h4>
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success text-center">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger text-center">
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="col-md-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route ('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Category List</li>
                </ol>
            </nav>
        </div>
    </div> 
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Category Data</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>                        
                                    <th>Title</th>                                        
                                    <th>Start Time</th>     
                                    <th>End Time</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ID</th>                        
                                    <th>Title</th>                                        
                                    <th>Start Time</th>     
                                    <th>End Time</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($cat->title); ?></td>
                                        <td><?php echo e($cat->start_time); ?></td>
                                        <td><?php echo e($cat->end_time); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div> 
</div> 
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cinch\resources\views/admin/category/index.blade.php ENDPATH**/ ?>