
<?php $__env->startSection('content'); ?>

<div class="mt-3">
    <div class="row">
        <div class="col-md-9 ">
            <h4>Food Categgory List</h4>
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success text-center">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger text-center">
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="col-md-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route ('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Food Category List</li>
                </ol>
            </nav>
        </div>
    </div> 
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Food Category Data</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>                        
                                    <th>Title</th>                                        
                                    <th>Category</th>     
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ID</th>                        
                                    <th>Title</th>                                        
                                    <th>Category</th>     
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($food->title); ?></td>
                                        <td><?php echo e($food->category->title); ?></td>
                                        <td>                                            
                                            <div class="row pl-3">                                                    
                                                <div class = "col-md-2">
                                                    <form action="<?php echo e(route('admin.food.destroy', $food->id)); ?>" method = "POST">
                                                        <?php echo e(csrf_field()); ?>

                                                        <?php echo e(method_field('DELETE')); ?>

                                                        <button type = "submit" name = "submit" value = "submit" data-toggle="tooltip" title="Delete Food Categgory" onclick = "return confirm('Do You Really Want to Delete?')" class = "btn btn-sm btn-circle btn-outline-danger" style = "margin-left: -10px;"><i class = "fa fa-trash"></i></button>
                                                    </form>
                                                </div> 
                                                <div class="col-md-2 ml-2">
                                                    <button type = "buttton" name = "edit" data-toggle="tooltip" title="Edit Food Categgory"  class = "btn btn-sm btn-circle btn-outline-primary" style = "margin-left: -10px;"><i class = "fa fa-pen"></i></button>
                                                </div>
                                            </div>                                           
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div> 
</div> 
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cinch\resources\views/admin/food/index.blade.php ENDPATH**/ ?>