<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\FoodCategory;
use App\Models\FoodCourse;

class FoodCategoryController extends Controller
{
    public function index(){
        try {
            $foodCategories = FoodCategory::get();
            return $this->success([sizeof($foodCategories) > 0 ? 'Category Found' : 'No Category Found', $foodCategories]);
        } catch (\Throwable $th) {
            return $this->error($th->getMessage());
        }
    }

    // get courses specific categories
    public function foodCourses(string $id){
        try {
            $course = FoodCourse::where('food_id',$id)->get();
            return $this->success([sizeof($course) > 0 ? 'Course Found' : 'No Course Found', $course]);
        } catch (\Throwable $th) {
            return $this->error($th->getMessage());
        }
    }

    // get specific courses
    public function viewCourse(string $id){
        try {
            $course = FoodCourse::where('id',$id)->get();
            return $this->success([sizeof($course) > 0 ? 'Course Found' : 'No Course Found', $course]);
        } catch (\Throwable $th) {
            return $this->error($th->getMessage());
        }
    }
}
